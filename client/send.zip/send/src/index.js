import React from 'react';
import ReactDOM from 'react-dom';
import Wrap from './Wrap';

ReactDOM.render(
  <React.StrictMode>
    <Wrap />
  </React.StrictMode>,
  document.getElementById('root')
);